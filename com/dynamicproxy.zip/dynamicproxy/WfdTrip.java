package dynamicproxy;

public class WfdTrip implements Trip{

	@Override
	public void goHome() {
		// TODO Auto-generated method stub
		System.out.println("fly from Melbourne to ShanDong!");
	}

}
