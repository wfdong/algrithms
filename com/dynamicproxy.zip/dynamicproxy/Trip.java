package dynamicproxy;

public interface Trip {
    public void goHome();
}
